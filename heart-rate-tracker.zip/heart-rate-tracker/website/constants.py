# Constants to be used in website files
# Dict name corresponds to the respective file name
# NOTE : Key should always be in ALL CAPS
# Add new constants at the end of the corresponding dictionary

init_constants = {
    "APP_CONFIG_SECRET_KEY": "kjsdifajefpoiannsaniucak",
    "MONGO_URI": "mongodb+srv://admin:batch2022@cluster0.vp7kz.mongodb.net/HRT?retryWrites=true&w=majority"
}